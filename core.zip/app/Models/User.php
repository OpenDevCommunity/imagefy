<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Notifications\DatabaseNotificationCollection;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Carbon;
use Laratrust\Traits\LaratrustUserTrait;
use Spatie\Activitylog\Models\Activity;

/**
 * App\Models\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property Carbon|null $email_verified_at
 * @property string $password
 * @property string|null $remember_token
 * @property Carbon|null $created_at
 * @property Carbon|null $updated_at
 * @property-read DatabaseNotificationCollection|DatabaseNotification[] $notifications
 * @property-read int|null $notifications_count
 * @method static \Illuminate\Database\Eloquent\Builder|User newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|User query()
 * @method static \Illuminate\Database\Eloquent\Builder|User whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmail($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereEmailVerifiedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePassword($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereRememberToken($value)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereUpdatedAt($value)
 * @mixin \Eloquent
 * @property-read Collection|Permission[] $permissions
 * @property-read int|null $permissions_count
 * @property-read Collection|Role[] $roles
 * @property-read int|null $roles_count
 * @method static \Illuminate\Database\Eloquent\Builder|User orWherePermissionIs($permission = '')
 * @method static \Illuminate\Database\Eloquent\Builder|User orWhereRoleIs($role = '', $team = null)
 * @method static \Illuminate\Database\Eloquent\Builder|User whereDoesntHavePermission()
 * @method static \Illuminate\Database\Eloquent\Builder|User whereDoesntHaveRole()
 * @method static \Illuminate\Database\Eloquent\Builder|User wherePermissionIs($permission = '', $boolean = 'and')
 * @method static \Illuminate\Database\Eloquent\Builder|User whereRoleIs($role = '', $team = null, $boolean = 'and')
 * @property-read Collection|Activity[] $Activity
 * @property-read int|null $activity_count
 * @property-read Collection|\App\Models\Image[] $Images
 * @property-read int|null $images_count
 * @property-read \App\Models\UserSetting|null $Settings
 * @property-read Collection|\App\Models\ShortUrl[] $ShortUrls
 * @property-read int|null $short_urls_count
 * @property string|null $api_token
 * @property-read Collection|\App\Models\APIKey[] $ApiKey
 * @property-read int|null $api_key_count
 * @property-read Collection|\App\Models\Image[] $Image
 * @property-read int|null $image_count
 * @property-read \App\Models\UserSetting|null $Setting
 * @property-read Collection|\App\Models\ShortUrl[] $ShortUrl
 * @property-read int|null $short_url_count
 * @method static \Illuminate\Database\Eloquent\Builder|User whereApiToken($value)
 */
class User extends Authenticatable
{
    use LaratrustUserTrait;
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    /**
     * @return HasMany
     */
    public function Image()
    {
        return $this->hasMany(Image::class, 'user_id', 'id');
    }


    /**
     * @return HasMany
     */
    public function ShortUrl()
    {
        return $this->hasMany(ShortUrl::class, 'user_id', 'id');
    }

    /**
     * @return Collection
     */
    public function PrivateImage()
    {
        return $this->hasMany(Image::class, 'user_id', 'id')
            ->where('public', false)->get();
    }

    /**
     * @return Collection
     */
    public function PublicImage()
    {
        return $this->hasMany(Image::class, 'user_id', 'id')
            ->where('public', true)->get();
    }

    /**
     * @return HasMany
     */
    public function ApiKey()
    {
        return $this->hasMany(APIKey::class, 'user_id', 'id');
    }

    /**
     * @return HasOne
     */
    public function Setting()
    {
        return $this->hasOne(UserSetting::class, 'user_id', 'id');
    }


    /**
     * @return HasMany
     */
    public function Activity()
    {
        return $this->hasMany(Activity::class, 'causer_id', 'id')->orderBy('created_at', 'desc');
    }


    /**
     * @return string
     */
    public function adminlte_profile_url()
    {
        return 'home';
    }
}

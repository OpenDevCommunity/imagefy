<?php $__env->startSection('title', env('APP_NAME') . ' - Administration Errors Index'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>View Error</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="conatiner">
        <section class="mt-3">
                <div class="card">
                    <div class="card-body">
                        <h5>Error Information</h5>
                        <span class="text-muted">Error information</span>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">
                                <p><strong>Code: </strong><?php echo e($error->code); ?></p>
                            </div>
                            <div class="col-md-4">
                                <p><strong>Occured: </strong><?php echo e($error->created_at->diffForHumans()); ?></p>
                            </div>
                            <div class="col-md-4">
                                <a href="<?php echo e(route('admin.errors.delete', $error->id)); ?>" data-text="This error log will be permanently deleted" class="btn btn-danger delete-confirm">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
        </section>

        <section class="mt-3">
            <div class="card">
                <div class="card-body">
                    <h5>Error Message</h5>
                    <span class="text-muted">Error message</span>
                    <hr>
                    <div class="trace">
                        <?php echo e($error->message); ?>

                    </div>
                </div>
            </div>
        </section>

        <section class="mt-3">
            <div class="card">
                <div class="card-body">
                    <h5>Trace</h5>
                    <span class="text-muted">Error trace information</span>
                    <hr>
                    <div class="trace">
                        <?php echo e($error->trace); ?>

                    </div>
                </div>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/errors/show.blade.php ENDPATH**/ ?>
<div class="sidebar" :class="[{'is-hidden': ! sidebar}]">
    <?php echo $index; ?>

</div><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/vendor/larecipe/partials/sidebar.blade.php ENDPATH**/ ?>
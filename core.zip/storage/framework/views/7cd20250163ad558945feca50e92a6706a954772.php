<div>
    <h4>User Uploaded Images</h4>
    <hr>
    <table id="user-images" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Image</th>
            <th>Uploaded</th>
            <th>Visibility</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(AWSImage::generateTempLink($img->image_name, 5)); ?>" data-toggle="lightbox" data-title="<?php echo e($img->image_name); ?>">
                        <?php echo e($img->image_name); ?>

                    </a>
                </td>
                <td><?php echo e($img->created_at->diffForHumans()); ?></td>
                <td>
                    <i class="text-success fas fa-<?php echo e(AWSImage::getFileVisibility($img->id) === 'public' ? 'globe' : 'lock'); ?>"
                       title="<?php echo e(AWSImage::getFileVisibility($img->id) === 'public' ? 'Public' : 'Private'); ?>"></i>
                </td>
                <td>
                <!--<a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-pencil-alt"></i></a> -->
                    <a href="<?php echo e(route('admin.image.delete', $img->id)); ?>" class="btn btn-danger delete-confirm btn-sm"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Registered</th>
            <th>Actions</th>
        </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/livewire/admin/users/images.blade.php ENDPATH**/ ?>
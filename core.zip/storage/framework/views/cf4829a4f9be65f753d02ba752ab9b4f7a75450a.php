<?php $__env->startSection('content'); ?>

    <div class="container">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb shadow-sm">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Account</a></li>
                <li class="breadcrumb-item active" aria-current="page">API Settings</li>
            </ol>
        </nav>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('list-api-keys', [])->html();
} elseif ($_instance->childHasBeenRendered('AhoU9eA')) {
    $componentId = $_instance->getRenderedChildComponentId('AhoU9eA');
    $componentTag = $_instance->getRenderedChildComponentTagName('AhoU9eA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AhoU9eA');
} else {
    $response = \Livewire\Livewire::mount('list-api-keys', []);
    $html = $response->html();
    $_instance->logRenderedChild('AhoU9eA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/user/account/api.blade.php ENDPATH**/ ?>
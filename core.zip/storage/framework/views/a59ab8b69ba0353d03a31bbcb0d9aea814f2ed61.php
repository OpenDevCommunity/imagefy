<?php $__env->startSection('title', env('APP_NAME') . ' - Edit Role'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit <?php echo e($role->display_name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('admin.update.role', $role->id)); ?>" method="POST">
        <div class="row">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4>Role Information</h4>
                        <hr>
                        <div class="form-group">
                            <label for="name">Name (Internal)</label>
                            <input type="text" id="name" name="name" value="<?php echo e($role->name); ?>" disabled class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="pname">Public Name</label>
                            <input type="text" id="pname" name="pname" value="<?php echo e($role->display_name); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <input type="text" id="description" name="description" value="<?php echo e($role->description); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <button class="btn btn-success btn-block" type="submit">Update <?php echo e($role->display_name); ?> role</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h4>Select Role Permissions</h4>
                        <hr>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group clearfix">
                                <div class="icheck-primary d-inline">
                                    <input type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" <?php echo e($role->hasPermission($permission->name) ? 'checked' : ''); ?> id="permission-<?php echo e($permission->id); ?>">
                                    <label for="permission-<?php echo e($permission->id); ?>">
                                        <?php echo e($permission->name); ?> <small>(<?php echo e($permission->description); ?>)</small>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/acl/roles/edit.blade.php ENDPATH**/ ?>
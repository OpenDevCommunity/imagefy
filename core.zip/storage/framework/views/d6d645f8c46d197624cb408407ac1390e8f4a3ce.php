<?php $__env->startSection('content'); ?>

    <div class="container">

        <!-- Statistics -->

        <div class="row">

            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1><?php echo e($shortURLSCount); ?></h1>
                        <p class="text-muted">All URLs</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1>0</h1>
                        <p class="text-muted">Clicks</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1><?php echo e($expiriedURLS); ?></h1>
                        <p class="text-muted">Expired URLs</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1>0</h1>
                        <p class="text-muted">URLs This Month</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->

        </div>

        <!-- ./ Statistics -->
    </div>

        <section class="mt-4">
            <div class="container">
                <?php $__currentLoopData = $shortUrls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow-sm" style="margin-top: 15px;">
                        <div class="card-body">
                            <h5><?php echo e($sh->name ? $sh->name : 'Not Available'); ?></h5>
                            <hr>
                            <div>
                                <p><strong>Original URL</strong></p>
                                <a href="<?php echo e($sh->original_url); ?>"><?php echo e(Str::limit($sh->original_url, 130)); ?></a>
                            </div>
                            <br>
                            <div>
                                <p><strong>Short URL</strong></p>
                                <p><a id="link" href="<?php echo e(route('frontend.shorturl', $sh->short_url_hash)); ?>"><?php echo e(route('frontend.shorturl', $sh->short_url_hash)); ?></a></p>
                            </div>

                            <?php if($sh->expiried): ?>
                            <div class="alert alert-warning">
                                This short URL has expired and will no longer redirect to required page! This URL expired <?php echo e(\Carbon\Carbon::parse($sh->expiries_at)->fromNow()); ?>

                            </div>
                           <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-4 float-right">
                    <?php echo e($shortUrls->links()); ?>

                </div>
            </div>
        </section>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/user/shorturls/index.blade.php ENDPATH**/ ?>
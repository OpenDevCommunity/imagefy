<div>
    <h4>User Roles</h4>
    <hr>
    <table id="roles-list" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Name</th>
            <th>Public Name</th>
            <th>Description</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($role->name); ?></td>
                <td><?php echo e($role->display_name); ?></td>
                <td><?php echo e($role->description); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Public Name</th>
            <th>Description</th>
        </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/livewire/admin/users/roles.blade.php ENDPATH**/ ?>
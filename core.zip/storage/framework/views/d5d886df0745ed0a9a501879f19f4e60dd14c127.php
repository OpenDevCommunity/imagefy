<div>
    <h4>User Infomration</h4>
    <hr>
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>" readonly class="form-control">
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" value="<?php echo e($user->email); ?>" readonly class="form-control">
    </div>
    <div class="form-group">
        <label for="reg_date">Registered</label>
        <input type="text" id="reg_date" name="email" value="<?php echo e($user->created_at->diffForHumans()); ?>" readonly class="form-control">
    </div>
</div>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/components/information.blade.php ENDPATH**/ ?>

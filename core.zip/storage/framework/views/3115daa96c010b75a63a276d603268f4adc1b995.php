<div>
    <h4>User permissions</h4>
    <hr>
    <table id="permissions-list" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Name</th>
            <th>Public Name</th>
            <th>Description</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user->allPermissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($permission->name); ?></td>
                <td><?php echo e($permission->display_name); ?></td>
                <td><?php echo e($permission->description); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <th>Name</th>
            <th>Public Name</th>
            <th>Description</th>
        </tr>
        </tfoot>
    </table>
</div>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/livewire/admin/users/permissions.blade.php ENDPATH**/ ?>
<div>
    <h4>User Short URLs</h4>
    <hr>
    <table id="short-urls" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Original Url</th>
            <th>Short URL</th>
            <th>Expiries At</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user->shorturls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e($url->original_url); ?>" target="_blank"><?php echo e(Str::limit($url->original_url, 50)); ?></a>
                </td>
                <td>
                    <a href="<?php echo e(route('frontend.shorturl', $url->short_url_hash)); ?>" target="_blank"><?php echo e(route('frontend.shorturl', $url->short_url_hash)); ?></a>
                </td>
                <td>
                    <?php echo e($url->expiried ? \Carbon\Carbon::parse($url->expities_at)->diffForHumans() : 'Expiried'); ?>

                </td>
                <td>
                    <button wire:click="destroy(<?php echo e($url->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <th>Original Url</th>
            <th>Short URL</th>
            <th>Expiries At</th>
            <th>Actions</th>
        </tr>
        </tfoot>
    </table>
</div>

<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/livewire/admin/users/short-urls.blade.php ENDPATH**/ ?>
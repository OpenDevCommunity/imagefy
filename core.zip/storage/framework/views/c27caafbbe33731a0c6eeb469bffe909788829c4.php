<?php $__env->startSection('title', config('app.name') . ' - Administration Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(config('app.name')); ?> Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="conatiner">
        <!-- Statistics -->

        <div class="row">

            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1><?php echo e($totalUsers); ?></h1>
                        <p class="text-muted">Total Users</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1><?php echo e($totalImages); ?></h1>
                        <p class="text-muted">Total Images</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1>0</h1>
                        <p class="text-muted">Private Images</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->


            <!-- Statistic Item -->
            <div class="col-lg-3">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h1><?php echo e($totalShortURLs); ?></h1>
                        <p class="text-muted">Short URLS</p>
                    </div>
                </div>
            </div>
            <!-- ./ Statistic Item -->

        </div>

        <!-- ./ Statistics -->


        <section class="mt-3">
            <div class="row">

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-success btn-sm float-right">View All</a>
                            <h5>Recent Users</h5>
                            <span class="text-muted">Recently registered users (5)</span>
                            <hr>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">email</th>
                                        <th scope="col">Registered</th>
                                        <th scope="col">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><p><?php echo e($user->email); ?></p></td>
                                            <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-cogs"></i>
                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="dropdown-item" title="Edit Image">
                                                            <i class="fas fa-eye"></i> View
                                                        </a>
                                                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="dropdown-item" title="Edit Image">
                                                            <i class="fas fa-pencil-alt"></i> Edit
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h5>Recent Events</h5>
                            <span class="text-muted">Recently recorded events (5)</span>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Event Description</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $recentEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('admin.users.show', Helper::getUserById($event->causer_id)->id)); ?>"><?php echo e(Helper::getUserById($event->causer_id)->name); ?></a>
                                            </td>
                                            <td><?php echo e($event->description); ?></td>
                                            <td><?php echo e($event->created_at->diffForHumans()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
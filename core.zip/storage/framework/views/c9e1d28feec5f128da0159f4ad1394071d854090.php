<?php $__env->startComponent('mail::message'); ?>
# Dear <?php echo e($email); ?>


Thank You for showing interest in joining <?php echo e(config('app.name')); ?>. As this is a private project and not
available to general public we do allow for users to request an invite. Please note that
not all requests are approved and there are many factors that can interfere with your request
such as we have reached users limit that we have set.

All requests are being reviewed from Monday - Friday @ 8:00 am - 10:00 pm (GMT) and Saturday - Sunday @ 11:00 am - 00:00 am (GMT).

We will do our best to get back to you within the next 48 hours. Please note that this is an estimated timeframe and might
not be met.

If you have any questions then feel free to send us an email to marek@marekdev.me

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/emails/inviteRequested.blade.php ENDPATH**/ ?>
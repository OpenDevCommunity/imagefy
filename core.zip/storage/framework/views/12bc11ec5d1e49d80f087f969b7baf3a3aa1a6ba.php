<?php $__env->startSection('title', config('app.name') . ' - Administration Errors Index'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Error Log</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="conatiner">
        <section class="mt-3">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.general.settings.update')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control" value="<?php echo e(config('app.name')); ?>">
                        </div>

                        <div class="form-group">
                            <button class="btn btn-success btn-block">Save Settings</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/app-settings/general-settings.blade.php ENDPATH**/ ?>
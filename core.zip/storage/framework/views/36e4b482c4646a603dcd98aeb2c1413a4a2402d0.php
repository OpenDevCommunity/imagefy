<?php $__env->startComponent('mail::message'); ?>
# Dear <?php echo e($email); ?>


Thank You for your interest in joining <?php echo e(config('app.name')); ?>. Unfortuantelly we were unable to accept your request.

There are many reasons why we are unable to approve your request such as we have reached amount of users
we can accept at this time.

Not to worry! You can always request invite again at later date and we might be able to accept your request.

If you have any questions then feel free to contact us at marek@marekdev.me.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/emails/inviteDeclined.blade.php ENDPATH**/ ?>
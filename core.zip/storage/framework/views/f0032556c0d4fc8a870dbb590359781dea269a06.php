<?php $__env->startSection('content'); ?>

    <div class="container">

         <!-- Connections -->
        <div class="card shadow-sm">
            <div class="card-body">
                <h5>Personal Information</h5>
                <br />

                <form action="#" method="POST">

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>">
                    </div>

                    <div class="form-group">
                        <button class="btn btn-success btn-block">Save Settings</button>
                    </div>

                </form>


            </div>
        </div>

        <!-- ./ Connections -->

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/user/account/settings.blade.php ENDPATH**/ ?>
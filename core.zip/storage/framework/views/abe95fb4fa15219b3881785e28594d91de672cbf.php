<?php $__env->startSection('title', env('APP_NAME') . ' - Edit User'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit <?php echo e($user->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h4>User Infomration</h4>
                <hr>
                <form action="<?php echo e(route('admin.users.update.information', $user->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <button class="btn btn-success btn-block">Save Infomration</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h4>User Roles</h4>
                <hr>
                <form action="<?php echo e(route('admin.users.sync.roles', $user->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group clearfix">
                                <div class="icheck-primary d-inline">
                                    <input type="checkbox" name="roles[]" <?php echo e($user->hasRole($role->name) ? 'checked' : ''); ?> value="<?php echo e($role->id); ?>" id="role-<?php echo e($role->id); ?>">
                                    <label for="role-<?php echo e($role->id); ?>">
                                        <?php echo e($role->name); ?> <small>(<?php echo e($role->description); ?>)</small>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <button class="btn btn-success btn-block">Save Roles</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#users').DataTable({
                "searching": true
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>
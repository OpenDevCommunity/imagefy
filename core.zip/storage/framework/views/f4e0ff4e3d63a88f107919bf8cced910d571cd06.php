<?php $__env->startSection('content'); ?>

    <div class="container">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb shadow-sm">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Account</a></li>
                <li class="breadcrumb-item active" aria-current="page">API Keys</li>
            </ol>
        </nav>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('list-api-keys', [])->html();
} elseif ($_instance->childHasBeenRendered('1NyYGKA')) {
    $componentId = $_instance->getRenderedChildComponentId('1NyYGKA');
    $componentTag = $_instance->getRenderedChildComponentTagName('1NyYGKA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1NyYGKA');
} else {
    $response = \Livewire\Livewire::mount('list-api-keys', []);
    $html = $response->html();
    $_instance->logRenderedChild('1NyYGKA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/user/account/api-keys/api.blade.php ENDPATH**/ ?>
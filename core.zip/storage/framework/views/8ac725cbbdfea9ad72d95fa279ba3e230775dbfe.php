<?php $__env->startSection('title', config('app.name') . ' - View User'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>View User <?php echo e($user->name); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-primary card-tabs">
        <div class="card-header p-0 pt-1">
            <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="custom-tabs-one-home-tab" data-toggle="pill" href="#information" role="tab" aria-controls="custom-tabs-one-home" aria-selected="true">Information</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#roles" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false">Roles</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-profile-tab" data-toggle="pill" href="#permissions" role="tab" aria-controls="custom-tabs-one-profile" aria-selected="false">Permissions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-messages-tab" data-toggle="pill" href="#images" role="tab" aria-controls="custom-tabs-one-messages" aria-selected="false">Images</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-settings-tab" data-toggle="pill" href="#short" role="tab" aria-controls="custom-tabs-one-settings" aria-selected="false">Short URLs</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="custom-tabs-one-settings-tab" data-toggle="pill" href="#activity" role="tab" aria-controls="custom-tabs-one-settings" aria-selected="false">Activity</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content" id="custom-tabs-one-tabContent">

                <!-- User Information -->
                <div class="tab-pane fade show active" id="information" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                    <h4>User Infomration</h4>
                    <hr>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo e($user->name); ?>" readonly class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e($user->email); ?>" readonly class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="reg_date">Registered</label>
                        <input type="text" id="reg_date" name="email" value="<?php echo e($user->created_at->diffForHumans()); ?>" readonly class="form-control">
                    </div>
                </div> <!-- User Information -->

                <!-- User Roles -->
                <div class="tab-pane fade" id="roles" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                    <h4>User Roles</h4>
                    <hr>
                    <table id="roles-list" class="table table-striped table-bordered dt-responsive" style="width:100%">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Public Name</th>
                            <th>Description</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->name); ?></td>
                                <td><?php echo e($role->display_name); ?></td>
                                <td><?php echo e($role->description); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Public Name</th>
                            <th>Description</th>
                        </tr>
                        </tfoot>
                    </table>
                </div> <!-- ./ User Roles -->

                <!-- User Permissions -->
                <div class="tab-pane fade" id="permissions" role="tabpanel" aria-labelledby="custom-tabs-one-profile-tab">
                    <h4>User permissions</h4>
                    <hr>
                    <table id="permissions-list" class="table table-striped table-bordered dt-responsive" style="width:100%">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Public Name</th>
                            <th>Description</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user->allPermissions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->display_name); ?></td>
                                <td><?php echo e($permission->description); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Public Name</th>
                            <th>Description</th>
                        </tr>
                        </tfoot>
                    </table>
                </div> <!-- User Permissions -->

                <!-- User Images -->
                <div class="tab-pane fade" id="images" role="tabpanel" aria-labelledby="custom-tabs-one-messages-tab">
                    <h4>User Uploaded Images</h4>
                    <hr>
                    <table id="user-images" class="table table-striped table-bordered dt-responsive" style="width:100%">
                        <thead>
                        <tr>
                            <th>Image</th>
                            <th>Uploaded</th>
                            <th>Visibility</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(AWSImage::generateTempLink($img->image_name, 5)); ?>" data-toggle="lightbox" data-title="<?php echo e($img->image_name); ?>">
                                        <?php echo e($img->image_name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($img->created_at->diffForHumans()); ?></td>
                                <td>
                                    <i class="text-success fas fa-<?php echo e(AWSImage::getFileVisibility($img->id) === 'public' ? 'globe' : 'lock'); ?>"
                                       title="<?php echo e(AWSImage::getFileVisibility($img->id) === 'public' ? 'Public' : 'Private'); ?>"></i>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-cogs"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a
                                                data-text="Image <?php echo e($img->image_name); ?> will be deleted permanently"
                                                class="dropdown-item delete-confirm"
                                                href="<?php echo e(route('admin.image.delete', $img->id)); ?>">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                        </tfoot>
                    </table>
                </div> <!-- User Images -->

                <!-- User Short URLS -->
                <div class="tab-pane fade" id="short" role="tabpanel" aria-labelledby="custom-tabs-one-settings-tab">
                    <h4>User Short URLs</h4>
                    <hr>
                    <table id="short-urls" class="table table-striped table-bordered dt-responsive" style="width:100%">
                        <thead>
                        <tr>
                            <th>Original Url</th>
                            <th>Short URL</th>
                            <th>Expiries At</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user->shorturl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e($url->original_url); ?>" target="_blank"><?php echo e(Str::limit($url->original_url, 50)); ?></a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('frontend.shorturl', $url->short_url_hash)); ?>" target="_blank"><?php echo e(route('frontend.shorturl', $url->short_url_hash)); ?></a>
                                </td>
                                <td>
                                    <?php echo e($url->expiries_at !== null  ? \Carbon\Carbon::parse($url->expiries_at)->diffForHumans() : 'Never Expiries'); ?>

                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-cogs"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a
                                                data-text="Short URL <?php echo e(route('frontend.shorturl', $url->short_url_hash)); ?> will be deleted permanently!"
                                                class="dropdown-item delete-confirm"
                                                href="<?php echo e(route('admin.user.del.shorturl', $url->id)); ?>">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Original Url</th>
                            <th>Short URL</th>
                            <th>Expiries At</th>
                            <th>Actions</th>
                        </tr>
                        </tfoot>
                    </table>
                </div> <!-- ./ User Short URLS -->

                <!-- User Activity -->
                <div class="tab-pane fade" id="activity" role="tabpanel" aria-labelledby="custom-tabs-one-settings-tab">
                    <h4>User Short URLs</h4>
                    <hr>
                    <table id="user-activity" class="table table-striped table-bordered dt-responsive" style="width:100%">
                        <thead>
                        <tr>
                            <th>Username</th>
                            <th>Activity</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user->activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($user->name); ?>

                                </td>
                                <td>
                                    <?php echo e($activity->description); ?>

                                </td>
                                <td>
                                    <?php echo e($activity->created_at->diffForHumans()); ?>

                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-cogs"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item delete-confirm" data-text="This user activity will be deleted permamently" href="#"><i class="fas fa-trash"></i> Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                        <tr>
                            <th>Username</th>
                            <th>Activity</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                        </tfoot>
                    </table>
                </div> <!-- ./ User Activity -->
            </div>
        </div>
        <!-- /.card -->
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#user-images, #short-urls, #permissions-list, #user-activity, #roles-list').DataTable({
                "searching": true
            });
        });
    </script>

    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox({
                alwaysShowClose: true
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/users/show.blade.php ENDPATH**/ ?>
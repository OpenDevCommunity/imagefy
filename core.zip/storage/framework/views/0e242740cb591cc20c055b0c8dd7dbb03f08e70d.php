<?php $__env->startComponent('mail::message'); ?>
# New Invite Request

A new invite request has been submitted by <?php echo e($email); ?>.

To accept or reject please login to administartion dashboard by
clicking on button bellow.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
View Pending Invite Requests
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/emails/newinviterequest.blade.php ENDPATH**/ ?>
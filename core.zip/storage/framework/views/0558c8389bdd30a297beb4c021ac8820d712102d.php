<?php $__env->startSection('title', config('app.name') . ' - Administration Errors Index'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Error Log</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="conatiner">
        <section class="mt-3">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">

                            <table id="errors-list" class="table table-striped table-bordered dt-responsive" style="width:100%">
                                <thead>
                                <tr>
                                    <th>Code</th>
                                    <th>Message</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($error->code); ?></td>
                                        <td><?php echo e(Str::limit($error->message, 150)); ?></td>
                                        <td><?php echo e($error->created_at->diffForHumans()); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-cogs"></i>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item" href="<?php echo e(route('admin.errors.show', $error->id)); ?>"><i class="fas fa-eye"></i> View</a>
                                                    <a class="dropdown-item delete-confirm" data-text="This error log will be permanently deleted" href="<?php echo e(route('admin.errors.delete', $error->id)); ?>"><i class="fas fa-trash"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Code</th>
                                    <th>Message</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('#errors-list').DataTable({
                "searching": true
            });
        } );
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/admin/errors/index.blade.php ENDPATH**/ ?>
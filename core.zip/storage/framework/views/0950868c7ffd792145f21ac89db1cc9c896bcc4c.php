<?php $__env->startSection('content'); ?>

    <div class="container">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb shadow-sm">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Account</a></li>
                <li class="breadcrumb-item active" aria-current="page">Your Images Library</li>
            </ol>
        </nav>

        <div class="row">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-sm-12 clearfix" style="margin-bottom: 15px !important;">
                    <div class="card shadow-sm">
                        <div class="card-body text-center">
                            <a href="<?php echo e(AWSImage::generateTempLink($image->image_name, 30)); ?>" data-toggle="lightbox" data-gallery="gallery">
                                <img src="<?php echo e(AWSImage::generateTempLink($image->image_name, 30)); ?>" class="img-fluid rounded">
                            </a>
                            <hr>
                            <p>
                                <span class="text-muted">Visibility: </span>
                                <i class="text-success fas fa-<?php echo e(AWSImage::getFileVisibility($image->id) === 'public' ? 'globe' : 'lock'); ?>"
                                   title="<?php echo e(AWSImage::getFileVisibility($image->id) === 'public' ? 'Public' : 'Private'); ?>"></i>
                            </p>
                            <p class="text-muted">Uploaded: <?php echo e($image->created_at->diffForHumans()); ?></p>
                            <hr>
                            <div class="row">
                                <div class="col-6">
                                    <a href="<?php echo e(route('user.image.settings', $image->image_share_hash)); ?>" class="btn btn-success btn-sm btn-block">Edit</a>
                                </div>
                                <div class="col-6">
                                    <a href="<?php echo e(route('user.image.delete', $image->image_del_hash)); ?>" class="btn btn-danger btn-sm btn-block delete-confirm">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).on("click", '[data-toggle="lightbox"]', function(event) {
            event.preventDefault();
            $(this).ekkoLightbox();
        });
    </script>

    <script>
        $('.delete-confirm').on('click', function (event) {
            event.preventDefault();
            const url = $(this).attr('href');
            swal({
                title: 'Are you sure?',
                text: 'This image and it`s details will be permanantly deleted!',
                icon: 'warning',
                buttons: ["Cancel", "Yes!"],
            }).then(function(value) {
                if (value) {
                    window.location.href = url;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/user/library/index.blade.php ENDPATH**/ ?>
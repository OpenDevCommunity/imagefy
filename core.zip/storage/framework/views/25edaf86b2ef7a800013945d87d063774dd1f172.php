<div>
    <div class="card shadow-sm">
        <div class="card-body">
            <button class="btn btn-success btn-sm float-right" wire:click="storeAPIKey">Generate Key</button>
            <h5>Your API Keys</h5>
            <br />

            <?php if(!$apiKeys || $apiKeys->count() < 1): ?>
                <div class="alert alert-warning">
                    Looks like you do not have any API Keys
                </div>
            <?php else: ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">API Key</th>
                        <th scope="col">Last Used</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $apiKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><kbd><?php echo e($key['api_key']); ?></kbd></td>
                        <td><?php echo e($key['last_used'] ? \Carbon\Carbon::parse($key['last_used'])->diffForHumans() : 'Not Available'); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-cogs"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="<?php echo e(route('user.settings.api.edit', $key->id)); ?>"><i class="fas fa-cog"></i>Settings</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.api.sharex',  ['id' => $key->id, 'type' => 'upload'])); ?>"><i class="fas fa-download"></i> Sharex Config</a>
                                    <a class="dropdown-item" href="<?php echo e(route('user.api.sharex', ['id' => $key->id, 'type' => 'surl'])); ?>"><i class="fas fa-download"></i> Sharex s-url Config</a>
                                    <a class="dropdown-item" href="javascript:void(0)" wire:click.prevent="delete(<?php echo e($key['id']); ?>)"><i class="fas fa-trash"></i> Delete</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/livewire/list-api-keys.blade.php ENDPATH**/ ?>
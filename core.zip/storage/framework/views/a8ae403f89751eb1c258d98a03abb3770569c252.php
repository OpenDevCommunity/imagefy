<?php $__env->startSection('content'); ?>

   <div class="container">

       <main role="main">
           <div class="jumbotron shadow-sm">
               <h1>Welcome to <?php echo e(config('app.name')); ?></h1>
               <p class="py-3">
                   <?php echo e(config('app.name')); ?> is a private image sharing & URL shortener built for personal use. As this project is private and not available to general public you can still request
                   an invite to be sent to you. Once you receive your invite you can then create an account. Please note that not every invite request will be approved but
                   why not to give it a try.
               </p>

               <p><strong>Current Version: </strong> <?php echo app('pragmarx.version')->format(); ?></p>
               <p><strong>Released: </strong> <?php echo e(\Carbon\Carbon::parse(Version::format('timestamp-full'))->fromNow()); ?></p>

               <p class="text-danger">
                   This project is in early alpha which means that you might find some nasty bugs that can be reported in your dashboard.
               </p>
               <a class="btn btn-lg btn-primary mt-2" href="<?php echo e(route('frontend.auth.request')); ?>" role="button">Request Invite &raquo;</a>
           </div>
       </main>

   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\websites\img.marekdev.me\resources\views/welcome.blade.php ENDPATH**/ ?>
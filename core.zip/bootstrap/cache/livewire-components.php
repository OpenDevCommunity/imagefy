<?php return array (
  'admin.users.images' => 'App\\Http\\Livewire\\Admin\\Users\\Images',
  'admin.users.information' => 'App\\Http\\Livewire\\Admin\\Users\\Information',
  'admin.users.permissions' => 'App\\Http\\Livewire\\Admin\\Users\\Permissions',
  'admin.users.roles' => 'App\\Http\\Livewire\\Admin\\Users\\Roles',
  'admin.users.short-urls' => 'App\\Http\\Livewire\\Admin\\Users\\ShortUrls',
  'image-visibility' => 'App\\Http\\Livewire\\ImageVisibility',
  'list-api-keys' => 'App\\Http\\Livewire\\ListApiKeys',
);
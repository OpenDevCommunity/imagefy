# API Documentation

---

- [Authentication](#section-1)
- [Upload Image](#section-1)


<a name="section-1"></a>
## Imagefy API Authentication

| Syntax      | Description |
| ----------- | ----------- |
| Header      | Title       |
| Paragraph   | Text        |



- ## Get Started
    - [Overview](/{{route}}/{{version}}/overview)
    
- ## Configurations
    - [ShareX Config](/{{route}}/{{version}}/sharex)
    
    
- ## API Docs
    - [Authentication](/{{route}}/{{version}}/api/authentication)
    - [Upload Image](/{{route}}/{{version}}/api/upload)
    - [Update Visibility](/{{route}}/{{version}}/api/visibility)
